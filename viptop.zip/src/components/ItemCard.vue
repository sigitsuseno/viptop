<template>
  <a
    :href="href"
    class="aspect-2/3 bg-blue-950 rounded-2xl shadow-lg hover:shadow-slate-700 shadow-slate-950 flex flex-col p-2"
  >
    <div class="w-full aspect-square overflow-clip rounded-md">
      <img
        :src="src"
        alt=""
        class="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
      />
    </div>
    <h5 class="lg:text-xl text-center mt-3">{{ title }}</h5>
  </a>
</template>

<script setup>
defineProps({
  href: {
    type: String,
    default: '/',
  },
  title: {
    type: String,
    default: 'Viptop Item',
  },
  src: {
    type: String,
    default: '/src/assets/default-bg.png',
  },
})
</script>
