<template>
  <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 w-full gap-4 my-8">
    <slot></slot>
  </div>
</template>
