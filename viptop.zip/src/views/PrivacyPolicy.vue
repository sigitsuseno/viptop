<template>
  <div class="container mx-auto p-4 lg:p-0 lg:pt-4">
    <h2 class="text-4xl font-bold">Website Terms of Use</h2>
    <h4 class="text-xl pb-8 mb-4 border-b border-blue-100">
      <strong>Last Updated: 1st October 2023</strong>
    </h4>
    <div class="prose max-w-none lg:max-w-none text-blue-100 text-justify">
      <!-- tempat Privacy & Policy -->

      ini privacy dan policy
    </div>
  </div>
</template>

<style scoped>
strong {
  color: orange;
}
h1,
h2,
h3,
h4,
h5,
h6 {
  color: var(--text-color);
}
</style>
