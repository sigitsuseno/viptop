<template>
  <div class="container mx-auto p-4 lg:p-0 lg:pt-4">
    <h2 class="text-4xl font-bold">Website Terms of Use</h2>
    <h4 class="text-xl pb-8 mb-4 border-b border-blue-100">
      <strong>Last Updated: 1st October 2023</strong>
    </h4>
    <div class="prose max-w-none lg:max-w-none text-blue-100 text-justify">
      <h3>
        IT IS IMPORTANT THAT YOU READ CAREFULLY AND UNDERSTAND THE FOLLOWING TERMS AND CONDITIONS.
      </h3>

      <p>
        These Terms and Conditions constitute a legally binding agreement made between you, whether
        personally or on behalf of an entity (“you”) and VipTop (“we,” “us” or “our”), concerning
        your access to and use of the www.VipTop.com website as well as any other media form, media
        channel, mobile website or mobile application related, linked, or otherwise connected
        thereto (collectively, the “Website”).
      </p>

      <p>
        You agree that by accessing the Website, you have read, understood, and agree to be bound by
        all of these Terms and Conditions. If you do not agree to these Terms and Conditions posted
        at the time you intend to access or use this website, please do not access or use this
        website, Product or any pages thereof.
      </p>

      <p>
        Any new features, upgrades, variations or new packages which are added to this website shall
        also be subject to these Terms and Conditions. VipTop reserves the right at its absolute and
        sole discretion to vary, modify, delete, update or suspend these Terms and Conditions (or
        any part thereof) for any reason, without prior notice to you. As such, you understand and
        acknowledge that it is your duty to review these Terms and Conditions on a regular basis.
        You will be subject to, and will be deemed to have been made aware of and to have accepted,
        the changes in any revised Terms and Conditions by your continued use of the Website after
        the date such revised Terms and Conditions are posted.
      </p>

      <p>
        The information provided on the Website is not intended for distribution to or use by any
        person or entity in any jurisdiction or country where such distribution or use would be
        contrary to law or regulation or which would subject us to any registration requirement
        within such jurisdiction or country.
      </p>

      <p>
        VipTop website are displayed in various languages for the purposes of enhancing user
        experience and interaction. Save as otherwise expressly stated, the use and display of any
        particular language or translation are purely to enhance user experience and shall not in
        any way be interpreted that VipTop is targeting or operating specifically in any particular
        country. VipTop is operates on the world wide web and caters to the language needs of its
        users internationally.
      </p>

      <p>
        Accordingly, those persons who choose to access the Website from other locations do so on
        their own initiative and are solely responsible for compliance with local laws, if and to
        the extent local laws are applicable.
      </p>

      <p>
        These Terms and Conditions apply to your use of all of this website has been developed by
        MOBILE ARTS SDN BHD. You acknowledge that you are aware of the contents of and agree to be
        legally bound by these Terms and Conditions.
      </p>

      <hr />

      <h4>GENERAL REQUIREMENTS FOR USE OF THE WEBSITE</h4>

      <ol>
        <li>
          <p>
            <strong>Age.</strong> The Website is intended for who are at least aged 18 years or
            older (or equivalent minimum age in the relevant jurisdiction), unless you are under 18
            years old and your account was provided to you as a result of a request by your parent
            or guardian. Parents and guardians should also remind any minors that conversing with
            strangers on the Internet can be dangerous and take appropriate precautions to protect
            children, including monitoring their use of the Website.
          </p>
          <p>
            To use the Website, you cannot be a person barred from receiving the Website under the
            laws of any relevant applicable jurisdictions, including the country in which you reside
            or from where you use the Website.
          </p>
        </li>

        <li>
          <p>
            <strong>Account.</strong> When you access our Website, you may be required to register
            an account (“<strong>Account</strong>”). By registering for an Account or by using our
            Website in any capacity, you represent that you are at least 18 years old (or equivalent
            minimum age in the relevant jurisdiction) and you understand and agree to these Terms
            and Conditions. If you are under the age of 18 (or equivalent minimum age in the
            relevant jurisdiction), you represent that your parents or your legal guardian has
            reviewed and agreed to these Terms and Conditions. If you access our Website through a
            third party platform, you are obligated to comply with their terms and conditions in
            addition to our Terms and Conditions.
          </p>

          <p>
            When you register for an account or update the information, you agree to provide us with
            accurate information and that you will keep it up-to-date at all times. You may never
            allow anyone else to use your account (except your parents or legal guardian). If you
            have reason to believe that your account is no longer secure, then you must immediately
            notify us at cs@VipTop.com. You are responsible for all activities that occur in your
            Account, whether or not you know about them.
          </p>
        </li>

        <li>
          <p><strong>Restrictions.</strong> you access our Website, you agree not to:</p>
          <ol type="a">
            <li>
              <p>
                Upload or transmit (or attempt to upload or to transmit) viruses, Trojan horses, or
                other material, including excessive use of capital letters and spamming (continuous
                posting of repetitive text), that interferes with any party’s uninterrupted use and
                enjoyment of the Website or modifies, impairs, disrupts, alters, or interferes with
                the use, features, functions, operation, or maintenance of the Website.
              </p>
            </li>
            <li>
              <p>
                Modify, make derivative works of, disassemble, decrypt, reverse compile or reverse
                engineer any part of the Website.
              </p>
            </li>
            <li>
              <p>
                Use the website to post contributions that are unlawful, obscene, vulgar,
                defamatory, abusive, damaging, disruptive, inappropriate, offensive, inaccurate,
                pornographic, vulgar, indecent, profane, hateful, racially or ethnically offensive,
                obscene, lewd, lascivious, filthy, threatening, excessively violent, harassing or
                otherwise objectionable.
              </p>
            </li>
            <li><p>Access, tamper with or using other VipTop users’ accounts.</p></li>
            <li>
              <p>
                Unauthorised monitoring of data or traffic on the Website, probing, scanning or
                testing the vulnerability of any of the Website system or network, or breaching any
                security or authentication measures; circumventing any technological measure that
                protect the Website.
              </p>
            </li>
          </ol>
          <p>
            You acknowledge that we have the right to monitor your access to and the use of
            VipTop.com to ensure your compliance with these Terms and Conditions, or to comply with
            applicable law or the order or requirement of a court or other governmental body.
            However, we do not undertake to do so and you shall take responsibility of your own
            actions in accessing and using the Website.
          </p>
        </li>
      </ol>

      <hr />

      <h4>INTELLECTUAL PROPERTY RIGHTS</h4>

      <p>
        Unless otherwise indicated, the Website is our proprietary property and all source code,
        databases, functionality, software, website designs, audio, video, text, photographs, and
        graphics on the Website (collectively, the “Content”) and the trademarks, product marks, and
        logos contained therein (the “Marks”) are owned or controlled by us or licensed to us, and
        are protected by copyright and trademark laws and various other intellectual property
        rights.
      </p>

      <p>
        The Content and the Marks are provided on the Website “AS IS” for your information and
        personal use only. Except as expressly provided in these Terms and Conditions, no part of
        the Website and no Content or Marks may be copied, reproduced, aggregated, republished,
        uploaded, posted, publicly displayed, encoded, translated, transmitted, distributed, sold,
        licensed, or otherwise exploited for any commercial purpose whatsoever, without our express
        prior written permission.
      </p>

      <p>
        Provided that you are eligible to use the Website, you are granted a limited license to
        access and use the Site for your personal, non-commercial use. We reserve all rights not
        expressly granted to you in and to the Website, the Content and the Marks.
      </p>

      <hr />
      <h4>LINKS TO THIRD-PARTY WEBSITES</h4>
      <p>
        The Website may contain (or you may be sent via the Website) links to other websites
        ("Third-Party Websites") as well as articles, photographs, text, graphics, pictures,
        designs, music, sound, video, information, applications, software, and other content or
        items belonging to or originating from third parties ("Third-Party Content").
      </p>

      <p>
        Such Third-Party Websites and Third-Party Content are not investigated, monitored, or
        checked for accuracy, appropriateness, or completeness by us, and we are not responsible for
        any Third-Party Websites accessed through the Site or any Third-Party Content posted on,
        available through, or installed from the Website, including the content, accuracy,
        offensiveness, opinions, reliability, privacy practices, or other policies of or contained
        in the Third-Party Websites or the Third-Party Content.
      </p>

      <p>
        Inclusion of, linking to, or permitting the use or installation of any Third-Party Websites
        or any Third-Party Content does not imply approval or endorsement thereof by us. If you
        decide to leave the Website and access the Third-Party Websites or to use or install any
        Third-Party Content, you do so at your own risk, and you should be aware these Terms and
        Conditions no longer govern.
      </p>

      <p>
        You should review the applicable terms and policies, including privacy and data gathering
        practices, of any website to which you navigate from the Website or relating to any
        applications you use or install from the Website. Any purchases you make through Third-Party
        Websites will be through other websites and from other companies, and we take no
        responsibility whatsoever in relation to such purchases which are exclusively between you
        and the applicable third party.
      </p>

      <p>
        You agree and acknowledge that we do not endorse the products offered on Third-Party
        Websites and you shall hold us harmless from any harm caused by your purchase of such
        products. Additionally, you shall hold us harmless from any losses sustained by you or harm
        caused to you relating to or resulting in any way from any Third-Party Content or any
        contact with Third-Party Websites.
      </p>

      <hr />

      <h4><strong>DISCLAIMER</strong></h4>

      <p>
        YOU EXPRESSLY UNDERSTAND AND AGREE THAT THE CONTENT, INFORMATION, LINKS, FUNCTIONALITY OF
        THIS WEBSITE AND PRODUCT ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS. WE AND OUR
        AFFILIATES (AND OUR AND THEIR RESPECTIVE EMPLOYEES, DIRECTORS, AGENTS AND REPRESENTATIVES),
        PARTNERS AND LICENSORS EXPRESSLY DISCLAIM ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR
        IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF NON INFRINGEMENT OF THIRD
        PARTY RIGHTS, TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND FREEDOM FROM
        COMPUTER VIRUS OR OTHER HARMFUL COMPONENTS. WITHOUT IN ANY WAY LIMITING THE PRIOR SENTENCE
        AND TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, WE MAKE NO REPRESENTATIONS OR
        WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, THAT (I) THE PRODUCT WILL MEET YOUR
        REQUIREMENTS; (II) YOUR USE OF THE PRODUCT AND/OR WEBSITE WILL BE TIMELY, UNINTERRUPTED,
        SECURE OR ERROR-FREE; (III) THE CONTENT AND INFORMATION OF THIS WEBSITE IS ACCURATE, SECURE,
        COMPLETE OR OTHERWISE FREE FROM ERRORS AND OMISSIONS; (IV) THE LINKS AND OTHER ASPECTS OF
        THE WEBSITE ARE FUNCTIONAL; OR (V) ANY DEFECTS OR ERRORS IN THE SOFTWARE PROVIDED TO YOU AS
        PART OF THE PRODUCT WILL BE CORRECTED.
      </p>

      <p>
        VipTop DOES NOT REPRESENT OR GUARANTEE THAT THE PRODUCT WILL BE FREE FROM LOSS, CORRUPTION,
        ATTACK, VIRUSES, INTERFERENCE, HACKING, OR OTHER SECURITY INTRUSION, AND VipTop DISCLAIMS
        ANY LIABILITY RELATING THERETO.
      </p>

      <p>
        You acknowledge that such information and materials may contain inaccuracies or errors and
        we expressly exclude liability for any such inaccuracies or errors to the fullest extent
        permitted by law.
      </p>

      <p>
        Your use of any information, material, or products on this website is entirely at your own
        discretion and risk, for which we shall not be liable. It shall be your own responsibility
        to ensure that any products, or information available through this website meet your
        specific requirements. You will be solely responsible for any damage to your device,
        computer, or loss of data that results from the use of the Product and/or website.
      </p>

      <hr />

      <h5>INDEMNIFICATION</h5>

      <p>
        You agree to indemnify, defend and hold VipTop, its affiliates, and their respective
        officers, directors, employees, agents, licensors, representatives, partners, and third
        party providers harmless from and against any and all claims, demand, losses, expenses,
        damages and costs, including but not limited to attorneys’ fees, relating to or arising
        from: (a) your use of the Product and/or website; (ii) any violation of these Terms and
        Conditions by you; (iii) any action taken by VipTop as part of its investigation of a
        suspected violation of these Terms and Conditions or as a result of its finding or decision
        that a violation of these Terms and Conditions has occurred; or (iv) any violation of any
        rights of another by you. This means that you cannot sue VipTop, its affiliates, and their
        respective officers, directors, employees, agents, licensors, representatives, partners, and
        third party providers as a result of its decision to remove or refuse to process any
        information or Content, to warn you, to suspend or terminate your access to the Product, or
        to take any other action during the investigation of a suspected violation or as a result of
        VipTop’s conclusion that a violation of these Terms and Conditions has occurred.
      </p>

      <p>
        This waiver and indemnity provision apply to all violations described in or contemplated by
        these Terms and Conditions. This obligation shall survive the termination or expiration of
        these Terms and Conditions and/or your use of the Product. You acknowledge that you are
        responsible for all use of the Product using your account, and that these Terms and
        Conditions apply to any and all usage of your account. You agree to comply with these Terms
        and Conditions and to defend, indemnify and hold VipTop harmless from and against any and
        all claims and demands arising from usage of your Account, whether or not such usage is
        expressly authorized by you.
      </p>

      <hr />

      <h5>GOVERNING LAW &amp; JURISDICTION</h5>

      <p>
        Notwithstanding from where you gain or attempt to gain access to this Website and/or the
        products herein, you agree that this Terms &amp; Conditions, your performance and conduct
        under it, your access to this Website and use of the products herein, content and any
        disputes arising thereunder shall, at all times, be governed by and construed in accordance
        with the laws of Malaysia without regard to its conflicts-of-law provisions, and you and
        VipTop agree to submit to the exclusive jurisdiction of the Malaysia courts.
      </p>
    </div>
  </div>
</template>

<style scoped>
strong {
  color: orange;
}
h1,
h2,
h3,
h4,
h5,
h6 {
  color: var(--text-color);
}
</style>
