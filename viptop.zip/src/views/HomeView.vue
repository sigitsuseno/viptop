<script setup>
import { ref } from 'vue'
import HeroSlider from './Home/HeroSlider.vue'

import HeadingTemplate from '@/components/HeadingTemplate.vue'
import ItemCard from '@/components/ItemCard.vue'
import CardHolder from '@/components/CardHolder.vue'

// gambar
import gambarFF from '@/assets/promo/ff.png'
import mlbb from '@/assets/promo/mlbb.png'
import apex from '@/assets/promo/apex.png'
import pubg from '@/assets/promo/pubg.png'
import cod from '@/assets/promo/slider-cod.png'
import steam from '@/assets/promo/steam-mh.png'
import headingBest from '@/assets/h-image.webp'
import headingPromo from '@/assets/bg-3.jpg'
import flashSale from '@/assets/tag.png'
import bestSeler from '@/assets/best.png'

const notif = ref(true)

const imageList = ref([
  { src: gambarFF, alt: 'Free Fire' },
  { src: mlbb, alt: 'Mobile Legends' },
  { src: apex, alt: 'Apex Legends' },
  { src: pubg, alt: 'PUBG' },
  { src: cod, alt: 'Call of Duty' },
  { src: steam, alt: 'Steam' },
])

const closeNotif = () => {
  notif.value = false
}
</script>

<template>
  <div class="flex flex-col justify-start relative">
    <!-- Notification Alert -->
    <div v-if="notif" class="container mx-auto p-4 relative">
      <button
        @click="closeNotif"
        class="absolute top-4 right-4 text-gray-500 hover:text-gray-700 transition-colors"
        aria-label="Close notification"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="h-6 w-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>
      <div class="text-center ring-1 ring-blue-400 rounded-lg p-4 bg-blue-950">
        <h2 class="text-2xl font-bold mb-2 text-blue-200">Topup Bergaransi</h2>
        <p class="text-sm text-blue-300">
          Lorem ipsum dolor. Iusto aliquid temporibus soluta inventore fuga molestiae illum atque
          magni itaque velit?
        </p>
      </div>
    </div>

    <!-- Main Content -->
    <section class="flex flex-col">
      <!-- Hero Slider -->
      <HeroSlider :images="imageList" />
    </section>
    <!-- Additional Content -->
    <section class="container m-auto flex flex-col items-start p-4 lg:p-0">
      <HeadingTemplate
        headingName="PROMO"
        :themeImage="flashSale"
        color="bg-purple-600"
        :headingImage="headingPromo"
      />
      <CardHolder>
        <ItemCard />
        <ItemCard />
        <ItemCard />
      </CardHolder>
    </section>

    <section class="container m-auto flex flex-col items-start p-4 lg:p-0">
      <HeadingTemplate
        headingName="Best Seller"
        :themeImage="bestSeler"
        :headingImage="headingBest"
      />
      <CardHolder>
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
      </CardHolder>
    </section>
  </div>
</template>

<style scoped>
/* Custom transitions for notification */
.notification-enter-active,
.notification-leave-active {
  transition: all 0.3s ease;
}

.notification-enter-from,
.notification-leave-to {
  opacity: 0;
  transform: translateY(-20px);
}
</style>
