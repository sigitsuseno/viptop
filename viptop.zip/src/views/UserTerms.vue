<template>
  <div class="container mx-auto p-4 lg:p-0 lg:pt-4">
    <h2 class="text-4xl font-bold">User Terms & Conditions</h2>
    <h4 class="text-xl pb-8 mb-4 border-b border-blue-100">
      <strong>Last Updated: 1st October 2023</strong>
    </h4>
    <div class="prose max-w-none lg:max-w-none text-blue-100 text-justify">
      <p>
        This web page represents our Terms and Conditions on the Use of the VipTop ("Terms"),
        located at <a href="https://www.VipTop.com">www.VipTop.com</a> and the tools provided by
        VipTop and/or its affiliates and governs all products offered by VipTop as particularly
        described below (“Products”). These Terms and Conditions apply to your use of all of VipTop
        Products and website developed by MOBILE ARTS SDN BHD. You acknowledge that you are aware of
        the contents of and agree to be legally bound by these Terms and Conditions. The terms, "we"
        and "our" as used in this Term refer to VipTop. Our Product permit you to make purchases at
        our Website using your mobile account or payment channels.
      </p>

      <p>
        We may amend these Term at any time by posting the amended terms on our Website. We may or
        may not post notices on the homepage of our Website when such changes occur. By assessing,
        using and making purchases using our Product, you are agreeing to these Terms.
      </p>

      <ol>
        <li>
          <p>
            VipTop reserves the right to refuse to provide the Product to anyone for any reason at
            any time. Your use of the Product and/or website is at your sole risk. In circumstances
            where you are authorized both to make purchases for the organization, you may make
            purchases using a corporate or business mobile account or payment instrument and shall
            agree to these Terms on its behalf.
          </p>
        </li>

        <li>
          <p>
            You expressly understand and agree that VipTop shall not be liable for any direct,
            indirect, incidental, special, consequential or exemplary damages, or damages for loss
            of profits, goodwill, use, data or other intangible losses resulting from the use of or
            inability to use the Product and/or website.
          </p>
        </li>

        <li>
          <p>
            In no event shall VipTop or our merchants be liable for lost profits or any special,
            incidental or consequential damages arising out of or in connection with our website,
            our Product or these Terms (however arising including negligence). You agree to
            indemnify and hold us and (as applicable) our parent, subsidiaries, affiliates,
            officers, directors, agents, and employees, harmless from any claim or demand, including
            reasonable attorneys´ fees, made by any third party due to or arising out of your breach
            of these Terms or the documents it incorporates by reference, or your violation of any
            law or the rights of a third party or your use of the Product and/or our website.
          </p>
        </li>

        <li>
          <p>
            The Product may provide, or third parties may provide, links to other World Wide Web
            (www) sites or resources. Because VipTop has no control over such websites and
            resources, you acknowledge and accept that VipTop is not responsible for the
            availability of such external websites or resources, and do not endorse and is not
            responsible or liable for any information, data, text, software, music, sound,
            photographs, graphics, video, messages, tags, or other materials ("Content"),
            advertising, products or other materials on or available from such websites or
            resources. As such, you also acknowledge and accept that VipTop does not and is not
            obligated to examine, evaluate or screen any of these external resources and does not
            warrant or endorse any of the information, content, offers or claims of these third
            parties. You further acknowledge and agree that VipTop shall not be responsible or
            liable, directly or indirectly, for any damage or loss caused or alleged to be caused by
            or in connection with use of or reliance on any such Content, goods available on or
            through any such website or resource.
          </p>
        </li>

        <li>
          <p>
            You agree not to alter, modify, reproduce, duplicate, copy, sell, resell or exploit any
            portion of the Product, use of the Product, or access to the Product without the express
            written permission by VipTop.
          </p>
        </li>

        <li>
          <p>
            The entire content of this website which consists of inter alia text, video (of any
            format, streaming or otherwise), audio clips (of any format, streaming or otherwise),
            data assemblages, graphics, logos, buttons, icons and any software (the "Site Content")
            is proprietary to VipTop or its content provider or other third parties and is protected
            under international and domestic copyright laws. The arrangement and/or compilation of
            the Website Content is proprietary to VipTop and is protected under international and
            domestic copyright laws.
          </p>
        </li>

        <li>
          <p>
            Verbal or written abuse of any kind (including but not limited to threats of abuse or
            retribution and defamatory statements) of any VipTop’s customer, employee, member, or
            officer will result in immediate account termination.
          </p>
        </li>

        <li>
          <p>
            The failure of VipTop to exercise or enforce any right or provision of the Terms and
            Conditions shall not constitute a waiver of such right or provision.
          </p>
        </li>

        <li>
          <p>Using our Product, you agree that:</p>
          <ol type="a">
            <li>transactions made via VipTop cannot be refuted once initiated.</li>
            <li>
              you are solely responsible in the usage of your mobile account or payment channel and
              that VipTop shall have no liability to you or any third party for any unauthorized use
              or access of VipTop through your mobile account or payment channels or in the event
              your mobile account or your account has been compromised. In such circumstances, it is
              your responsibility to inform your mobile operator or your payment channel of such
              instances.
            </li>
            <li>
              any taxes, duties, currency exchange fees, data charges and any other applicable
              charges in relation to your purchases via VipTop shall be borne by you.
            </li>
            <li>
              VipTop, or your mobile operator if made purchase via your mobile account or your
              chosen payment channel provided at VipTop.com has the sole discretion to accept or
              decline a transaction performed by you through VipTop for whatsoever reason, and that,
              should this occur, VipTop shall not be held liable to you.
            </li>
            <li>
              you have consented to be contacted by VipTop, and to receive notices electronically,
              including but not limited to by text message, from us. You agree that we may make any
              notices that we may be required by law to make in electronic format. These
              communications will be deemed to be in writing and received by you when sent to you.
            </li>
            <li>
              you may be required to register with the Website. You agree to keep your password
              confidential and will be responsible for all use of your account and password. We
              reserve the right to remove, reclaim, or change a username you select if we determine,
              in our sole discretion, that such username is inappropriate, obscene, or otherwise
              objectionable.
            </li>
          </ol>
          <p></p>
        </li>

        <li>
          <p>As a user of our Product, you agree not to:</p>
          <ol type="a">
            <li>
              use the Product in any way that violates any applicable law or for any unlawful
              purpose.
            </li>
            <li>disparage, tarnish, or otherwise harm, VipTop, our websites, or our Product.</li>
            <li>
              make any unauthorized use or access of the Product, including collecting usernames
              and/or email addresses of users by electronic or other means for the purpose of
              sending unsolicited email, or creating user account by automated means or under false
              pretences.
            </li>
            <li>
              use a buying agent or purchasing agent to make purchases using our Products and
              thereafter charge other directly or indirectly for such uses.
            </li>
            <li>
              attempt to impersonate another user or person or use the username of another user.
            </li>
            <li>
              use any information obtained from the Website in order to harass, abuse, or harm
              another person.
            </li>
            <li>
              systematically retrieve data or other content from the Website to create or compile,
              directly or indirectly, a collection, compilation, database, or directory without
              written permission from us.
            </li>
            <li>
              circumvent, disable, or otherwise interfere with security-related features of the
              Website, including features that prevent or restrict the use or copying of any content
              or enforce limitations on the use of the Website and/or the content contained therein.
            </li>
            <li>engage in unauthorized framing of or linking to the Website/Product.</li>
            <li>
              trick, defraud, or mislead us and other users, especially in any attempt to learn
              sensitive account information such as user passwords;
            </li>
            <li>
              make improper use of our support services or submit false reports of abuse or
              misconduct.
            </li>
            <li>
              engage in any automated use of the system, such as using scripts to send comments or
              messages, or using any data mining, robots, or similar data gathering and extraction
              tools.
            </li>
            <li>
              interfere with, disrupt, or create an undue burden on the Website or the networks or
              Product connected to the Website.
            </li>
            <li>
              decipher, decompile, disassemble, or reverse engineer any of the software comprising
              or in any way making up a part of the Website.
            </li>
            <li>
              attempt to bypass any measures of the Website designed to prevent or restrict access
              to the Website, or any portion of the Website.
            </li>
            <li>
              harass, annoy, intimidate, or threaten any of our employees or agents engaged in
              providing any portion of the Product to you.
            </li>
          </ol>
          <p></p>
        </li>

        <li>
          <p>
            VipTop reserves the right to deny payments from suspicious buyers. In the event that an
            order or payment is tagged as being suspicious, delivery of item(s) will be delayed
            until VipTop can successfully verify its legitimacy, be it by phone or a request for
            verifying information. The determination of what amounts to suspiciousness shall be at
            the sole and absolute discretion of VipTop. You acknowledge and accept that under the
            laws of certain jurisdiction, VipTop may be obligated to report any suspicious
            transactions to the relevant authorities.
          </p>
        </li>

        <li>
          <p>
            Unless you notify VipTop to the contrary on the day of delivery and such notification is
            confirmed by email, the Product shall be deemed to have been accepted by you as being in
            good order and in accordance with the terms and conditions under which the Product is
            offered by VipTop.
          </p>
        </li>

        <li>
          <p>
            You undertake to make all payments promptly and in accordance with any rules,
            regulations or guidelines issued by VipTop from time to time and shall not be entitled
            to withhold payment of all or any of the price.
          </p>
        </li>

        <li>
          <p>
            All transactions made in accordance with these Terms and Conditions are final. The
            Product that has been delivered are strictly non-refundable.
          </p>
        </li>

        <li>
          <p>
            If you have any complaints about our website and/or Product, you should direct them to
            us via e-mail at <a href="mailto:cs@VipTop.com">cs@VipTop.com.</a>
          </p>
        </li>

        <li>
          <p>VipTop Products</p>
          <ol type="a">
            <li>
              <strong>VipTop Credits</strong> are not legal tender. It is a virtual credit which
              allow users to reload and spend on any online and mobile games available at VipTop.com
              and VipTop content partners payment platform.
            </li>
            <li>
              <strong>VipTop voucher</strong> is a game voucher which carries VipTop Credits in the
              form of a physical voucher or softpin. Each VipTop vouchers comprise of a unique
              serial number and pin code which allow users to reload VipTop Credits into their
              VipTop account or perform flash top up into games which is available at VipTop.com and
              VipTop content partners payment platform.
            </li>
            <li>
              <strong>VipTop Reward Program Membership</strong> (“Program”) implemented and operated
              by PT. 24 Jam Online. Under the Program, if you have signed up for the Program as a
              VipTop Reward member (“Coin”), we allow you to collect Coin through the purchase of
              VipTop Credits at VipTop.com portal website and to use the Coin you have collected to
              redeem VipTop Credits, merchandise, gift certificates and other reward (“Reward”) that
              is provided by suppliers, manufacturers, retailers, and content providers (“Partners”)
              being offered by us from time to time. Registration, membership, and all benefits will
              be subjected to the Terms and Conditions of the specific Program. By registering in
              the Program or Coin collection, you agree that you have read and understood the Terms
              &amp; Conditions and are bound by all the Terms &amp; Conditions, that may be
              subjected to change from time to time, and also agree for us to collect and use your
              personal information in accordance with our Privacy Policy. The Terms &amp; Conditions
              herein is between us and you and relate to your participation in the Program, your
              right to collect, use, redeem the Reward and your right to other benefits of the
              Program. If you are dealing with us in regards to the internet, you hereby allow the
              forming of a contractual agreement through electronic communication. We have the final
              authority in the interpretation of the Terms &amp; Conditions and other related
              questions in relation to the Program or the Reward. Our failure to carry out any of
              the provisions of the Terms &amp; Conditions at any time may not be interpreted as a
              relinquishment of rights or the rights of all parties to conduct violations over any
              provision or any other provision of this Terms &amp; Conditions. You may not divert or
              transfer your rights or obligations under the Terms &amp; Conditions without prior
              written permission from us.

              <ol type="i">
                <p><strong>Participation in the Program</strong></p>
                <li>
                  VipTop membership only applies to individuals, not to companies, organizations or
                  any other body.
                </li>
                <li>
                  To register in the Program, you must (i) register or sign up to acquire a VipTop
                  account (“Account”), (ii) inform us, mailing address in Indonesia and a valid
                  email address, and (iii) be at least 18 (eighteen)years old and if you are under
                  the age of 18 (or equivalent minimum age in the relevant jurisdiction), we require
                  you to obtain permission from your legal guardian to register for an account and
                  that the legal guardian must agree to these Terms and Conditions. If you are the
                  legal guardian of a minor who is registering for an Account, you must accept these
                  Terms and Conditions on the minor’s behalf and you will be responsible for all use
                  of the Account, including any transactions made by the minor, whether the minor’s
                  account is now open or created later and whether or not the minor is supervised by
                  you during his or her use of our Product.
                </li>
                <li>
                  If we accept your registration application, we will sign you up in the Program as
                  a VipTop Reward Program member (“Member”), you must provide any change to your
                  personal data to us, such as name, mailing address, email address, and phone
                  number by contacting our Customer Support at
                  <a href="mailto:cs@VipTop.com">cs@VipTop.com</a> or you may renew your personal
                  data through www.VipTop.com (“Member Web Portal“)
                </li>
                <li>
                  In the event, your account is lost and you forgot Your email and access code, you
                  will lose all of Your Coin.
                </li>
                <li>
                  VipTop reserves the right to terminate your membership at any time for whatsoever
                  reason VipTop deem fit.
                </li>
                <p></p>
                <p>
                  <strong>PIN (Personal Identification Number)</strong>
                </p>
                <li>
                  Email is required to access the Member Account and to redeem your Coin, or when
                  contacting Customer Support at <a href="mailto:cs@VipTop.com">cs@VipTop.com</a>
                </li>
                <li>
                  You are responsible for ensuring that you keep your email confidential at all
                  times and to notify us over any illegal use of your email or when your email is
                  compromised.
                </li>
                <li>
                  We are not responsible or accountable in any way over losses arising from your
                  failure to fulfil these conditions.
                </li>
                <p></p>
                <p></p>
                <p><strong>Coin Acquisition</strong></p>
                <li>
                  Coin are acquired for every purchase of VipTop Credits made by using the payment
                  channels provided at VipTop.com website.
                </li>
                <li>To acquire Coin you must perform a transaction purchase at www.VipTop.com</li>
                <li>
                  Coin will then be automatically added to your VipTop membership Account no later
                  than 24 hours after the transaction has been initiated.
                </li>
                <li>
                  You will acquire VipTop Coin for every transaction that is perform at VipTop with
                  the term of 0.01% of the transaction value. Further VipTop reserves the right to
                  change the provision at any time.
                </li>
                <p></p>
                <p>
                  <strong>Coin Expiration</strong>
                  Coin expires 12 months after the date it is acquired.
                </p>
                <p>
                  <strong>Coin Usage</strong>
                  Coin does not have any cash value, monetary value, or other values, and cannot be
                  converted to any currency. Coin are calculated according to the Reward Program
                  that we provide from time to time. VipTop reserves the right to set the amount of
                  Coin required to redeem or convert into any goods or benefits that will be
                  exchanged and to alter the amount at any time, without prior notice.
                </p>
              </ol>
            </li>
          </ol>
        </li>
      </ol>

      <hr />

      <h5>INTELLECTUAL PROPERTY RIGHTS</h5>

      <p>
        If you purchase any digital content from the website, it is exclusively for your personal
        consumption. You have no right to reproduce it for any reason. Except for the licenses
        granted in these Terms and Conditions, you have no right, title or interest in or to VipTop
        or its Product. The content and information of this website is protected by intellectual
        property rights law and owned by VipTop and/or the proprietary property of its suppliers,
        affiliates, or licensors. Without VipTop’s prior written permission, you may not copy,
        reproduce, publish, distribute, transmit, display, license, sell, circulate, create
        derivative works from, or otherwise exploit the content and information of this website to
        any third party (including, without limitation, the display and distribution of the material
        via a third party websites or other networked computer environment).
      </p>

      <p>
        Unauthorized use of this website, including without limitation, unauthorized entry into the
        VipTop systems, misuse of passwords or misuse of any information posted on the website is
        strictly prohibited. In addition, use of this website is unauthorized in any jurisdiction
        where the use of this website may violate any applicable legal requirements.
      </p>

      <p>
        All trademarks, product marks, trade names, logos and icons (collectively
        "<strong>Trademarks</strong>") displayed on our website are registered and unregistered
        Trademarks of VipTop and others. Nothing contained in our website should be construed as
        granting, by implication, estoppel, or otherwise, any licence or right to use any Trademark
        displayed on our website without the written permission of VipTop or such third party that
        may own the Trademarks displayed on our website. Your use of the Trademarks displayed on our
        website, or any other content on our website, is strictly prohibited.
      </p>

      <hr />

      <h5>DISCLAIMER OF WARRANTIES</h5>

      <p>
        VipTop DOES NOT GUARANTEE, REPRESENT, OR WARRANT THAT YOUR USE OF THE PRODUCT AND/OR WEBSITE
        WILL BE UNINTERRUPTED OR ERROR-FREE, AND YOU AGREE THAT FROM TIME TO TIME WE MAY REMOVE THE
        PRODUCT FOR INDEFINITE PERIODS OF TIME, OR CANCEL THE PRODUCT IN ACCORDANCE WITH THESE TERMS
        AND CONDITIONS.
      </p>
      <p>
        We have no control over the quality, fitness, safety, reliability, legality, or any other
        aspect of any Product that is purchased using our Product. We are not required to issue
        refunds if a purchase turns out to not meet your expectations, or if the third party
        providers do not fulfil their commitments, although we will make reasonable efforts to
        assist you in these matters. We have no obligation, and cannot guarantee that, we will
        resolve any disputes related to any transaction to your satisfaction.
      </p>
      <p>
        We have the absolute discretion to alter the Terms &amp; Conditions, in any way in respect
        of the Program, including terms of ordering, Coin usage procedures for Reward, or Reward in
        any form, without prior notice, and even if the changes can affect the value of the
        accumulated Coin. You must check our present Terms &amp; Conditions and details and other
        information for the Program through the Member Web Portal or by calling our Customer Support
        at <a href="mailto:cs@VipTop.com">cs@VipTop.com</a>.
      </p>

      <p>
        Our website content are provided based on “as is” and “as available”. We hereby firmly state
        that we do not make any guarantees or collaterals whether expressly or implicitly, in
        respect to the merchantability of a product or suitability of our product that we provide
        for a specific purpose.
      </p>

      <p>
        From time to time, our Product may be delayed, interrupted or disrupted for an indeterminate
        period of time. In addition, except as otherwise required by applicable law or regulation,
        VipTop may terminate your use of Product or impose limits on the type and/or amount of
        transactions you are allowed to make with the Product at any time at its sole discretion
        without prior notice. VipTop and its affiliates shall not be liable for any claim arising
        from or related to VipTop arising from any such delay, interruption, disruption, limitation,
        or suspension.
      </p>

      <hr />

      <h5>LIMITATION OF LIABILITY</h5>

      <p>
        YOU EXPRESSLY UNDERSTAND AND AGREE THAT TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW,
        WE AND OUR AFFILIATES (AND OUR AND THEIR RESPECTIVE EMPLOYEES, DIRECTORS, AGENTS AND
        REPRESENTATIVES), PARTNERS AND LICENSORS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT,
        INCIDENTAL, SPECIAL, PUNITIVE, CONSEQUENTIAL OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED
        TO, DAMAGES FOR LOSS OF PROFITS, GOODWILL, USE, DATA COST OF PROCUREMENT OF SUBSTITUTE
        PRODUCTS, OR OTHER INTANGIBLE LOSSES ARISING OUT OF OR IN CONNECTION WITH: (i) THE USE OR
        INABILITY TO USE THE PRODUCT; (ii) ANY CHANGES MADE TO THE PRODUCT OR ANY TEMPORARY OR
        PERMANENT CESSATION OF THE PRODUCT OR ANY PART THEREOF; (iii) THE UNAUTHORIZED ACCESS TO OR
        ALTERATION OF YOUR TRANSMISSIONS OR DATA; (iv) THE DELETION OF, CORRUPTION OF, OR FAILURE TO
        STORE AND/OR SEND OR RECEIVE YOUR TRANSMISSIONS OR DATA ON OR THROUGH THE PRODUCT; (v)
        STATEMENTS OR CONDUCT OF ANY THIRD PARTY ON THE PRODUCT; (vi) PROGRAM OR YOUR PARTICIPATION
        IN THE PROGRAM, (vii) DELAY, FAILURE OR DECISION BY US IN THE OPERATION OF THE PROGRAM OR
        ANY CHANGES TO THE TERMS AND CONDTIONS ON THE REDEMPTION AND USAGE OF THE POINTS (viii)
        ILLEGITIMATE USE OF YOUR MEMBER CARD OR PIN, (ix) OFFERS, DESCRIPTION, STATEMENTS OR CLAIMS
        ABOUT THE PROGRAM, BRANDS OR PARTNERSHIP OR ANY INDIVIDUAL, (x) PURCHASES, REDEMPTIONS OR
        USAGE OF GOODS FROM THE BRAND OR PARTNERSHIP, INCLUDING OTHER REWARD, WHETHER PROVIDED BY US
        OR ONE OF OUR AFFILIATES, BRAND OR PARTNER. OUR BRAND AND PARTNERS ARE NOT ACCOUNTABLE FOR
        THE PROGRAM AND (xi) ANY OTHER MATTER RELATING TO THE PRODUCT AND/OR WEBSITE.
      </p>
      <p>
        TO THE EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT WILL THE AGGREGATE LIABILITY OF
        VipTop OR OUR AFFILIATES (AND OUR AND THEIR RESPECTIVE EMPLOYEES, DIRECTORS, AGENTS AND
        REPRESENTATIVES), PARTNERS AND LICENSORS ARISING OUT OF OR IN CONNECTION WITH THESE TERMS
        AND CONDITIONS OR THE TRANSACTIONS CONTEMPLATED HEREBY, WHETHER IN CONTRACT, TORT (INCLUDING
        NEGLIGENCE, PRODUCT LIABILITY OR OTHER THEORY), WARRANTY, OR OTHERWISE, EXCEED THE AMOUNT OF
        FEES EARNED BY US IN CONNECTION WITH YOUR USE OF PRODUCT AND/OR WEBSITE DURING THE THREE (3)
        MONTH PERIOD IMMEDIATELY PRECEDING THE EVENT GIVING RISE TO THE CLAIM FOR LIABILITY.
      </p>

      <hr />

      <h5>NO REFUND POLICY</h5>

      <p>
        VipTop digital Products have a strict no-refund policy. Please be sure the products are
        right for you before purchasing. Users are solely responsible for confirming that their
        devices are compatible with the Products they purchase. All virtual item purchased are
        final, non-refundable and non-returnable. We do not offer refunds or exchanges for the
        incorrect purchase of VipTop Products, including due to compatibility issues.
      </p>

      <hr />

      <h5>TERMINATION</h5>

      <p>
        VipTop may at any time, under certain circumstances and without prior notice, immediately
        terminate or suspend all or a portion of your Account and/or access to the Product. Cause
        for such termination shall include: (a) violations of this Agreement or any other policies
        or guidelines that are referenced herein and/or posted on the Product; (b) a request by you
        to cancel or terminate your Account; (c) a request and/or order from law enforcement, a
        judicial body, or other government agency; (d) where provision of the Product to you is or
        may become unlawful; (e) unexpected technical or security issues or problems; (f) your
        participation in fraudulent or illegal activities; or (g) failure to pay any fees owed by
        you in relation to the Product, provided that in the case of non-material breach, VipTop
        will be permitted to terminate only after giving you 30 days’ notice and only if you have
        not cured the breach within such 30-day period. Any such termination or suspension shall be
        made by VipTop in its sole discretion and VipTop will not be responsible to you or any third
        party for any damages that may result or arise out of such termination or suspension of your
        Account and/or access to the Product.
      </p>
      <p>
        In addition, VipTop may terminate your Account upon 30 days’ prior notice via email to the
        address associated with your Account if (a) your Account has been inactive for one (1) year;
        or (b) there is a general discontinuance of the Product or any part thereof. Notice of
        general discontinuance of Product will be provided as set forth herein, unless it would not
        be reasonable to do so due to circumstances arising from legal, regulatory, or governmental
        action; to address user security, user privacy, or technical integrity concerns; to avoid
        disruptions to other users; or due to a natural disaster, a catastrophic event, war, or
        other similar occurrence outside of VipTop’s reasonable control.
      </p>
      <p>
        Should you breach any of these Terms and Conditions, VipTop shall have the exclusive sole
        and absolute right to terminate, discontinue or withdraw the provision of the Product to
        you. In the event of a breach by you, VipTop reserves its right to pursue any remedy or
        relief in so far as permitted by law, which includes but is not limited to injunction,
        damages and/or specific performance.
      </p>

      <hr />

      <h5>PRIVACY POLICY</h5>

      <p>Please refer to our <a href="privacy-policy">privacy policy</a>.</p>

      <hr />

      <h5>MISCELLANEOUS</h5>

      <p>
        VipTop is not a bank, e-money issuer, or money transferor and does not require the approval
        of the relevant Authorities to operate. Your prepaid or post-paid mobile account is not a
        bank account, e-money account, payment card, or other regulated financial instrument. VipTop
        does not process or store your credit or debit card number. This Agreement shall be governed
        by and construed according to the laws of Malaysia without regard to its conflicts-of-law
        provisions, and you and VipTop agree to submit to the exclusive jurisdiction of the Malaysia
        courts. Nothing in these Terms and Conditions is intended to or creates any type of joint
        venture, employee-employer, creditor-debtor, escrow, partnership, or any fiduciary
        relationship between you, us, or our affiliates. VipTop may assign this Agreement, any of
        its terms, and any of VipTop obligations, in whole or in part, at any time, with or without
        notice to you, but you may not assign this Agreement, or any part of it, to any other party
        without VipTop’s prior written approval. Any attempt by you to do so is void.
      </p>
      <p>
        Notwithstanding any law, rule or regulation to the contrary, you agree that any claim or
        cause of action you may have arising out of these Terms and Conditions must be filed within
        one (1) year after such claim or cause of action first could be filed or be forever barred.
        We will not be considered to have waived any of our rights or remedies, or portion of them,
        unless the waiver is in writing and signed by us. Our failure to enforce the strict
        performance of any provision of these Terms and Conditions will not constitute a waiver of
        our right to subsequently enforce such provision or any other provisions.
      </p>
      <p>
        These Terms and Conditions constitute the entire agreement between you and VipTop, and
        supersede and cancel all prior and contemporaneous agreements, claims, representations, and
        understandings (including, but not limited to, any prior versions of the Terms and
        Conditions). No modification or amendment of this Agreement will be binding on VipTop unless
        set forth in writing signed by us.
      </p>

      <p>
        If any part of this Agreement is held by a court of competent jurisdiction to be invalid or
        unenforceable, the remaining terms and conditions of this Agreement will remain in full
        force and effect and, upon our request, the court will construe any invalid or unenforceable
        portions in a manner that most closely reflects the economic, legal and business objectives
        of the original language. If such construction is not possible, the provision will be
        severed from this Agreement and the rest of the Agreement will remain in full force and
        effect.
      </p>

      <p>
        These Terms and Conditions were written in English. To the extent any translated version of
        this Agreement conflicts with the English version, the English version controls and
        prevails. We reserve the right to change, modify or otherwise alter these Terms and
        Conditions at any time. You can find the most recent version on our website. Such
        modifications shall become effective immediately upon the posting thereof.
      </p>
    </div>
  </div>
</template>

<style scoped>
strong {
  color: orange;
}
h1,
h2,
h3,
h4,
h5,
h6 {
  color: var(--text-color);
}
</style>
