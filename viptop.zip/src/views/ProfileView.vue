<script setup></script>

<template>
  <h1>Profile</h1>
</template>
